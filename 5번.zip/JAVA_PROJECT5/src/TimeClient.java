import java.io.*;
import java.net.*;

public class TimeClient {
    public static void main(String[] args) {
        final String SERVER_ADDRESS = "localhost";
        final int SERVER_PORT = 24123;

        try (Socket socket = new Socket(SERVER_ADDRESS, SERVER_PORT);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

            System.out.println("서버에 접속함");

            System.out.print("서버의 시간: ");
            String response;
            while ((response = in.readLine()) != null) {
                System.out.print(response + " ");
                System.out.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("\n연결 종료");
    }
}
