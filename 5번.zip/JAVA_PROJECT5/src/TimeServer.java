import java.io.*;
import java.net.*;
import java.util.concurrent.*;

public class TimeServer {
    public static void main(String[] args) {
        final int PORT = 24123;

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("타임서버");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("연결완료");

                ExecutorService executor = Executors.newSingleThreadExecutor();
                executor.submit(() -> handleClient(clientSocket));
                executor.shutdown();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void handleClient(Socket clientSocket) {
        try (PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {
            int counter = 1; 
            long startTime = System.currentTimeMillis();

            while (System.currentTimeMillis() - startTime < 10000) {
                out.println(counter++);
                Thread.sleep(500);
            }
            
            System.out.println("연결종료");
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
