import java.io.File;
import java.util.Scanner;

public class FileExplorer {

    private File currentDirectory;

    public FileExplorer() {
    	
        currentDirectory = new File("C:\\");
    
    }

    public void listFiles() {
    	
        File[] files = currentDirectory.listFiles();
        if (files != null) {
        	
            for (File file : files) {
            	
                String type = file.isDirectory() ? "dir " : "file";
                System.out.printf("%-5s      %-15s      %s\n", type, file.length() + "바이트", file.getName());
                
            }
            
        }
    }

    public void navigate(String command) {
    	
        if (command.equals("..")) {
        	
            File parent = currentDirectory.getParentFile();
            
            if (parent != null) {
            	
                currentDirectory = parent;
                
            }
            
        } else {
        	
            File newDir = new File(currentDirectory, command);
            
            if (newDir.exists() && newDir.isDirectory()) {
                
            	currentDirectory = newDir;
            	
            } else {
            	
                System.out.println("Invalid directory: " + command);
                
            }
        }
    }

    public static void main(String[] args) {
    	
        FileExplorer explorer = new FileExplorer();
        Scanner scanner = new Scanner(System.in);
        String command;

        System.out.println("***** 파일 탐색기입니다. *****");

        while (true) {
        	
            System.out.println("         [" + explorer.currentDirectory.getAbsolutePath() + "]");
            explorer.listFiles();
            System.out.print(">> ");
            command = scanner.nextLine();

            if (command.equals("..") || new File(explorer.currentDirectory, command).isDirectory()) {
            	
                explorer.navigate(command);
                
            } else {
            	
                while (true) {
                	
                    System.out.print(">> ");
                    command = scanner.nextLine();
                    
                    if (command.equals("..") || new File(explorer.currentDirectory, command).isDirectory()) {
                        explorer.navigate(command);
                        break;
                        
                    }
                }
            }
        }
    }
}
