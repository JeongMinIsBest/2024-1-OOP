import java.util.HashMap;
import java.util.Scanner;

public class CustomerManager {

    private HashMap<String, Integer> customerPoints;

    public CustomerManager() {
    	
        customerPoints = new HashMap<>();
    
    }

    public void addPoints(String name, int points) {
    	
        customerPoints.put(name, customerPoints.getOrDefault(name, 0) + points);
   
    }

    public void printCustomerPoints() {
    	
        for (String name : customerPoints.keySet()) {
        	
            System.out.print("(" + name + ", " + customerPoints.get(name) + ") ");
        
        }
        
        System.out.println();
        
    }

    public static void main(String[] args) {
    	
        CustomerManager cm = new CustomerManager();
        Scanner scanner = new Scanner(System.in);

        System.out.println("** 포인트 관리 프로그램입니다 **");

        while (true) {
        	
            System.out.print("이름과 포인트 입력 >> ");
            String input = scanner.nextLine().trim();
            
            if (input.equalsIgnoreCase("exit")) {
                break;
                
            }
            
            String[] parts = input.split("\\s+");
            
            if (parts.length != 2) {
            	
                System.out.println("이름과 포인트를 공백으로 구분하여 입력해주세요!");
                continue;
                
            }
            
            String name = parts[0];
            int points;
            
            try {
            	
                points = Integer.parseInt(parts[1]);
            } catch (NumberFormatException e) {
            	
                System.out.println("포인트는 정수로 입력해주세요.");
                continue;
                
            }
            
            cm.addPoints(name, points);
            cm.printCustomerPoints();
            
        }

        System.out.println("최종 포인트 결과:");
        cm.printCustomerPoints();

        scanner.close();
    }
}
