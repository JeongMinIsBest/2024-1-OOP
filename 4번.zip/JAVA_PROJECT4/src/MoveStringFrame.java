import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MoveStringFrame extends JFrame {
	
    private JLabel label;
    private String text = "Love Java";

    public MoveStringFrame() {
    	
        setTitle("Love Java를 움직여보자!");
        setSize(300, 100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        label = new JLabel(text, SwingConstants.CENTER);
        label.setFont(new Font("Serif", Font.PLAIN, 24));
        add(label);

        addKeyListener(new KeyAdapter() {
        	
            @Override
            public void keyPressed(KeyEvent e) {
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_LEFT:
                        text = rotateLeft(text);
                        break;
                    case KeyEvent.VK_RIGHT:
                        text = rotateRight(text);
                        break;
                        
                }
                
                label.setText(text);
                
            }
        });

        setFocusable(true);
        setVisible(true);
    }

    private String rotateLeft(String str) {
    	
        return str.substring(1) + str.charAt(0);
        
    }

    private String rotateRight(String str) {
    	
        return str.charAt(str.length() - 1) + str.substring(0, str.length() - 1);
        
    }

    public static void main(String[] args) {
    	
        new MoveStringFrame();
        
    }
}
