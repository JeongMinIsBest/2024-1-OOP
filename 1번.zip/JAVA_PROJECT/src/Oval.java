class Oval implements Shape {
	
	private int majorAxis;
	private int minorAxis;
	
	public Oval(int majorAxis, int minorAxis) {
		
		this.majorAxis = majorAxis;
		this.minorAxis = minorAxis;
	
	}
	
	@Override
	public void draw() {
		System.out.println(majorAxis + "x" + minorAxis + "에 내접하는 타원입니다.");
		
	}
	
	@Override
	public double getArea() {
		return PI * majorAxis * minorAxis;
	
	}

}
